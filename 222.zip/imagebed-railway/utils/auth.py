import hashlib
import hmac
import json
import base64
import time
import secrets


class Auth:
    __slots__ = ('secret',)

    def __init__(self, secret):
        self.secret = secret.encode() if isinstance(secret, str) else secret

    def hash_password(self, password):
        salt = secrets.token_hex(16)
        pwdhash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
        return salt + pwdhash.hex()

    def verify_password(self, stored, provided):
        salt = stored[:32]
        stored_hash = stored[32:]
        pwdhash = hashlib.pbkdf2_hmac('sha256', provided.encode(), salt.encode(), 100000)
        return hmac.compare_digest(stored_hash, pwdhash.hex())

    def generate_token(self, user_id, username, role):
        header = base64.urlsafe_b64encode(json.dumps({'alg': 'HS256', 'typ': 'JWT'}).encode()).rstrip(b'=')
        payload = base64.urlsafe_b64encode(json.dumps({
            'uid': user_id,
            'sub': username,
            'role': role,
            'iat': int(time.time()),
            'exp': int(time.time()) + 86400
        }).encode()).rstrip(b'=')
        signature = base64.urlsafe_b64encode(
            hmac.new(self.secret, header + b'.' + payload, hashlib.sha256).digest()
        ).rstrip(b'=')
        return (header + b'.' + payload + b'.' + signature).decode()

    def verify_token(self, token):
        try:
            parts = token.split('.')
            if len(parts) != 3:
                return None
            header, payload, signature = parts
            expected_sig = base64.urlsafe_b64encode(
                hmac.new(self.secret, (header + '.' + payload).encode(), hashlib.sha256).digest()
            ).rstrip(b'=')
            if not hmac.compare_digest(signature.encode(), expected_sig):
                return None
            padding = 4 - len(payload) % 4
            if padding != 4:
                payload += '=' * padding
            payload_data = json.loads(base64.urlsafe_b64decode(payload))
            if payload_data.get('exp', 0) < time.time():
                return None
            return payload_data
        except Exception:
            return None

    def generate_access_token(self):
        return secrets.token_urlsafe(32)
