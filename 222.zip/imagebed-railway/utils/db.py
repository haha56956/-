import sqlite3
import threading
import time


class Database:
    __slots__ = ('path', 'local', 'lock')

    def __init__(self, path):
        self.path = path
        self.local = threading.local()
        self.lock = threading.Lock()
        self.init_db()

    def get_conn(self):
        if not hasattr(self.local, 'conn') or self.local.conn is None:
            self.local.conn = sqlite3.connect(self.path, check_same_thread=False, timeout=10)
            self.local.conn.row_factory = sqlite3.Row
            self.local.conn.execute('PRAGMA journal_mode=WAL')
            self.local.conn.execute('PRAGMA synchronous=NORMAL')
            self.local.conn.execute('PRAGMA cache_size=-8000')
            self.local.conn.execute('PRAGMA temp_store=MEMORY')
        return self.local.conn

    def init_db(self):
        conn = self.get_conn()
        conn.executescript('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT DEFAULT 'user',
                group_id INTEGER DEFAULT 1,
                storage_quota INTEGER DEFAULT 104857600,
                file_count_limit INTEGER DEFAULT 100,
                created_at REAL DEFAULT (unixepoch())
            );
            CREATE TABLE IF NOT EXISTS files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                filename TEXT NOT NULL,
                original_name TEXT NOT NULL,
                file_type TEXT NOT NULL,
                file_size INTEGER NOT NULL,
                storage_backend TEXT NOT NULL,
                storage_path TEXT NOT NULL,
                access_token TEXT UNIQUE NOT NULL,
                created_at REAL DEFAULT (unixepoch())
            );
            CREATE TABLE IF NOT EXISTS groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                storage_quota INTEGER DEFAULT 104857600,
                file_count_limit INTEGER DEFAULT 100
            );
            CREATE TABLE IF NOT EXISTS config (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS servers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                url TEXT NOT NULL,
                auth_token TEXT NOT NULL,
                role TEXT DEFAULT 'peer',
                status TEXT DEFAULT 'offline',
                last_seen REAL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS cost_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT NOT NULL,
                cost REAL NOT NULL,
                details TEXT DEFAULT '{}'
            );
            CREATE TABLE IF NOT EXISTS access_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                module TEXT NOT NULL,
                action TEXT NOT NULL,
                user_id INTEGER DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_files_user ON files(user_id);
            CREATE INDEX IF NOT EXISTS idx_files_token ON files(access_token);
            CREATE INDEX IF NOT EXISTS idx_access_logs_ts ON access_logs(timestamp);
            INSERT OR IGNORE INTO groups (id, name, storage_quota, file_count_limit)
            VALUES (1, 'default', 104857600, 100);
        ''')
        conn.commit()

    def execute(self, sql, params=()):
        with self.lock:
            conn = self.get_conn()
            cursor = conn.execute(sql, params)
            conn.commit()
            return cursor

    def fetchone(self, sql, params=()):
        with self.lock:
            return self.get_conn().execute(sql, params).fetchone()

    def fetchall(self, sql, params=()):
        with self.lock:
            return self.get_conn().execute(sql, params).fetchall()

    def get_user(self, username):
        return self.fetchone('SELECT * FROM users WHERE username = ?', (username,))

    def get_user_by_id(self, user_id):
        return self.fetchone('SELECT * FROM users WHERE id = ?', (user_id,))

    def create_user(self, username, password_hash, role='user', group_id=1):
        self.execute(
            'INSERT INTO users (username, password_hash, role, group_id) VALUES (?, ?, ?, ?)',
            (username, password_hash, role, group_id)
        )
        return self.get_user(username)

    def get_user_stats(self, user_id):
        row = self.fetchone(
            'SELECT COUNT(*) as count, COALESCE(SUM(file_size), 0) as total_size FROM files WHERE user_id = ?',
            (user_id,)
        )
        return {'file_count': row['count'], 'total_size': row['total_size']}

    def add_file(self, user_id, filename, original_name, file_type, file_size, storage_backend, storage_path, access_token):
        self.execute(
            'INSERT INTO files (user_id, filename, original_name, file_type, file_size, storage_backend, storage_path, access_token) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            (user_id, filename, original_name, file_type, file_size, storage_backend, storage_path, access_token)
        )

    def get_file_by_filename(self, user_id, filename):
        return self.fetchone('SELECT * FROM files WHERE user_id = ? AND filename = ?', (user_id, filename))

    def get_file_by_token(self, access_token):
        return self.fetchone('SELECT * FROM files WHERE access_token = ?', (access_token,))

    def get_file_by_id(self, file_id):
        return self.fetchone('SELECT * FROM files WHERE id = ?', (file_id,))

    def delete_file(self, file_id):
        self.execute('DELETE FROM files WHERE id = ?', (file_id,))

    def get_user_files(self, user_id):
        return self.fetchall('SELECT * FROM files WHERE user_id = ? ORDER BY created_at DESC', (user_id,))

    def get_config(self, key):
        row = self.fetchone('SELECT value FROM config WHERE key = ?', (key,))
        return row['value'] if row else None

    def set_config(self, key, value):
        self.execute('INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)', (key, str(value)))

    def get_all_users(self):
        return self.fetchall('SELECT id, username, role, group_id, storage_quota, file_count_limit, created_at FROM users')

    def update_user_quota(self, user_id, storage_quota, file_count_limit):
        self.execute('UPDATE users SET storage_quota = ?, file_count_limit = ? WHERE id = ?',
                      (storage_quota, file_count_limit, user_id))

    def delete_user(self, user_id):
        self.execute('DELETE FROM files WHERE user_id = ?', (user_id,))
        self.execute('DELETE FROM users WHERE id = ?', (user_id,))

    def get_all_groups(self):
        return self.fetchall('SELECT * FROM groups')

    def create_group(self, name, storage_quota, file_count_limit):
        self.execute('INSERT INTO groups (name, storage_quota, file_count_limit) VALUES (?, ?, ?)',
                      (name, storage_quota, file_count_limit))

    def update_group(self, group_id, storage_quota, file_count_limit):
        self.execute('UPDATE groups SET storage_quota = ?, file_count_limit = ? WHERE id = ?',
                      (storage_quota, file_count_limit, group_id))

    def delete_group(self, group_id):
        self.execute('UPDATE users SET group_id = 1 WHERE group_id = ?', (group_id,))
        self.execute('DELETE FROM groups WHERE id = ?', (group_id,))

    def add_server(self, name, url, auth_token, role='peer'):
        self.execute('INSERT INTO servers (name, url, auth_token, role) VALUES (?, ?, ?, ?)',
                      (name, url, auth_token, role))

    def get_servers(self):
        return self.fetchall('SELECT * FROM servers')

    def update_server_status(self, server_id, status):
        self.execute('UPDATE servers SET status = ?, last_seen = unixepoch() WHERE id = ?',
                      (status, server_id))

    def log_access(self, module, action, user_id=0):
        self.execute('INSERT INTO access_logs (timestamp, module, action, user_id) VALUES (unixepoch(), ?, ?, ?)',
                      (module, action, user_id))

    def get_access_stats(self, since):
        return self.fetchall(
            'SELECT module, COUNT(*) as count FROM access_logs WHERE timestamp > ? GROUP BY module',
            (since,)
        )

    def get_hourly_stats(self, since):
        return self.fetchall(
            "SELECT CAST(strftime('%H', timestamp, 'unixepoch') AS INTEGER) as hour, COUNT(*) as count FROM access_logs WHERE timestamp > ? GROUP BY hour",
            (since,)
        )

    def log_cost(self, date, cost, details='{}'):
        self.execute('INSERT INTO cost_logs (date, cost, details) VALUES (?, ?, ?)',
                      (date, cost, details))

    def get_recent_costs(self, days=7):
        return self.fetchall(
            'SELECT * FROM cost_logs ORDER BY date DESC LIMIT ?',
            (days,)
        )

    def get_total_storage_used(self):
        row = self.fetchone('SELECT COALESCE(SUM(file_size), 0) as total FROM files')
        return row['total']

    def cleanup_old_logs(self, days=30):
        cutoff = time.time() - (days * 86400)
        self.execute('DELETE FROM access_logs WHERE timestamp < ?', (cutoff,))
        self.execute("DELETE FROM cost_logs WHERE date < date('now', ?)", (f'-{days} days',))

    def close(self):
        if hasattr(self.local, 'conn') and self.local.conn:
            self.local.conn.close()
            self.local.conn = None
