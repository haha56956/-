import time
import threading
from collections import defaultdict


class RateLimiter:
    __slots__ = ('requests', 'lock', 'config')

    def __init__(self, config=None):
        self.requests = defaultdict(list)
        self.lock = threading.Lock()
        self.config = config

    def configure(self, config):
        self.config = config

    def is_allowed(self, client_id):
        if self.config is not None:
            max_requests = self.config.get_int('rate_limit_max', 120)
            window = self.config.get_int('rate_limit_window', 60)
        else:
            max_requests, window = 120, 60

        with self.lock:
            now = time.time()
            self.requests[client_id] = [t for t in self.requests[client_id] if now - t < window]
            if len(self.requests) > 4096:
                for key in [k for k, v in self.requests.items() if not v]:
                    del self.requests[key]
            if len(self.requests[client_id]) >= max_requests:
                return False
            self.requests[client_id].append(now)
            return True


rate_limiter = RateLimiter()
