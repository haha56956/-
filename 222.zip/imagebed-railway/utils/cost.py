import time
import os

SERVICE_START = time.time()


class CostCalculator:
    __slots__ = ('config', 'start_time', 'ram_gb', 'cpu_vcpu')

    RAM_PER_GB_MONTH = 10.0
    CPU_PER_VCPU_MONTH = 20.0
    EGRESS_PER_GB = 0.05
    VOLUME_PER_GB_MONTH = 0.15

    RAM_PER_GB_MINUTE = RAM_PER_GB_MONTH / (30 * 24 * 60)
    CPU_PER_VCPU_MINUTE = CPU_PER_VCPU_MONTH / (30 * 24 * 60)

    def __init__(self, config=None):
        self.config = config
        self.start_time = SERVICE_START
        self.ram_gb = float(os.environ.get('RAILWAY_RAM_GB', '0.5'))
        self.cpu_vcpu = float(os.environ.get('RAILWAY_CPU_VCPU', '1'))

    @property
    def daily_budget(self):
        if self.config is not None:
            return self.config.get_float('daily_budget', 0.03)
        return float(os.environ.get('DAILY_BUDGET', '0.03'))

    def estimate_cost(self, runtime_minutes, egress_gb=0, volume_gb=0):
        ram_cost = self.ram_gb * self.RAM_PER_GB_MINUTE * runtime_minutes
        cpu_cost = self.cpu_vcpu * self.CPU_PER_VCPU_MINUTE * runtime_minutes
        egress_cost = egress_gb * self.EGRESS_PER_GB
        volume_cost = volume_gb * self.VOLUME_PER_GB_MONTH / 30
        return ram_cost + cpu_cost + egress_cost + volume_cost

    def get_current_daily_cost(self):
        runtime_minutes = (time.time() - self.start_time) / 60
        return self.estimate_cost(runtime_minutes)

    def get_budget_status(self):
        budget = self.daily_budget
        current = self.get_current_daily_cost()
        ratio = current / budget if budget > 0 else 0
        if ratio < 0.7:
            return 'normal'
        elif ratio < 0.9:
            return 'warning'
        else:
            return 'emergency'

    def should_enable_mini_ui(self):
        return self.get_budget_status() == 'emergency'

    def get_recommended_action(self):
        status = self.get_budget_status()
        if status == 'normal':
            return 'all_features'
        elif status == 'warning':
            return 'disable_non_essential'
        else:
            return 'mini_ui_only'
