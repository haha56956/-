import os

MASKED = '********'

SCHEMA = {
    'storage_type': {'env': 'STORAGE_TYPE', 'default': 'none', 'type': 'str', 'group': 'Storage', 'label': 'Storage Backend', 'secret': False,
                     'options': ['none', 'redis', 'tidb', 's3', 'alist', 'ftp', 'oss']},
    's3_bucket': {'env': 'STORAGE_BUCKET', 'default': '', 'type': 'str', 'group': 'S3', 'label': 'Bucket', 'secret': False},
    's3_region': {'env': 'STORAGE_REGION', 'default': 'us-east-1', 'type': 'str', 'group': 'S3', 'label': 'Region', 'secret': False},
    's3_endpoint': {'env': 'STORAGE_ENDPOINT', 'default': '', 'type': 'str', 'group': 'S3', 'label': 'Endpoint URL', 'secret': False},
    's3_access_key': {'env': 'STORAGE_ACCESS_KEY', 'default': '', 'type': 'str', 'group': 'S3', 'label': 'Access Key', 'secret': True},
    's3_secret_key': {'env': 'STORAGE_SECRET_KEY', 'default': '', 'type': 'str', 'group': 'S3', 'label': 'Secret Key', 'secret': True},
    'redis_url': {'env': 'REDIS_URL', 'default': '', 'type': 'str', 'group': 'Redis', 'label': 'Redis URL', 'secret': True},
    'tidb_host': {'env': 'TIDB_HOST', 'default': '', 'type': 'str', 'group': 'TiDB / MySQL', 'label': 'Host', 'secret': False},
    'tidb_port': {'env': 'TIDB_PORT', 'default': '4000', 'type': 'int', 'group': 'TiDB / MySQL', 'label': 'Port', 'secret': False},
    'tidb_user': {'env': 'TIDB_USER', 'default': 'root', 'type': 'str', 'group': 'TiDB / MySQL', 'label': 'User', 'secret': False},
    'tidb_password': {'env': 'TIDB_PASSWORD', 'default': '', 'type': 'str', 'group': 'TiDB / MySQL', 'label': 'Password', 'secret': True},
    'tidb_database': {'env': 'TIDB_DATABASE', 'default': 'imagebed', 'type': 'str', 'group': 'TiDB / MySQL', 'label': 'Database', 'secret': False},
    'alist_url': {'env': 'ALIST_URL', 'default': '', 'type': 'str', 'group': 'Alist', 'label': 'Alist URL', 'secret': False},
    'alist_token': {'env': 'ALIST_TOKEN', 'default': '', 'type': 'str', 'group': 'Alist', 'label': 'API Token', 'secret': True},
    'ftp_host': {'env': 'FTP_HOST', 'default': '', 'type': 'str', 'group': 'FTP', 'label': 'Host', 'secret': False},
    'ftp_port': {'env': 'FTP_PORT', 'default': '21', 'type': 'int', 'group': 'FTP', 'label': 'Port', 'secret': False},
    'ftp_user': {'env': 'FTP_USER', 'default': '', 'type': 'str', 'group': 'FTP', 'label': 'User', 'secret': False},
    'ftp_pass': {'env': 'FTP_PASS', 'default': '', 'type': 'str', 'group': 'FTP', 'label': 'Password', 'secret': True},
    'oss_endpoint': {'env': 'OSS_ENDPOINT', 'default': '', 'type': 'str', 'group': 'OSS', 'label': 'Endpoint', 'secret': False},
    'oss_bucket': {'env': 'OSS_BUCKET', 'default': '', 'type': 'str', 'group': 'OSS', 'label': 'Bucket', 'secret': False},
    'oss_access_key': {'env': 'OSS_ACCESS_KEY', 'default': '', 'type': 'str', 'group': 'OSS', 'label': 'Access Key', 'secret': True},
    'oss_secret_key': {'env': 'OSS_SECRET_KEY', 'default': '', 'type': 'str', 'group': 'OSS', 'label': 'Secret Key', 'secret': True},
    'daily_budget': {'env': 'DAILY_BUDGET', 'default': '0.03', 'type': 'float', 'group': 'Budget', 'label': 'Daily Budget ($)', 'secret': False},
    'total_storage_limit': {'env': 'TOTAL_STORAGE_LIMIT', 'default': '524288000', 'type': 'int', 'group': 'Limits', 'label': 'Total Storage Limit (bytes)', 'secret': False},
    'default_storage_quota': {'env': 'DEFAULT_STORAGE_QUOTA', 'default': '104857600', 'type': 'int', 'group': 'Limits', 'label': 'Default User Storage Quota (bytes)', 'secret': False},
    'default_file_count_limit': {'env': 'DEFAULT_FILE_COUNT_LIMIT', 'default': '100', 'type': 'int', 'group': 'Limits', 'label': 'Default User File Count Limit', 'secret': False},
    'max_upload_size': {'env': 'MAX_UPLOAD_SIZE', 'default': '10485760', 'type': 'int', 'group': 'Limits', 'label': 'Max Upload Size (bytes)', 'secret': False},
    'rate_limit_max': {'env': 'RATE_LIMIT_MAX', 'default': '120', 'type': 'int', 'group': 'Limits', 'label': 'Rate Limit Requests', 'secret': False},
    'rate_limit_window': {'env': 'RATE_LIMIT_WINDOW', 'default': '60', 'type': 'int', 'group': 'Limits', 'label': 'Rate Limit Window (seconds)', 'secret': False},
    'site_name': {'env': 'SITE_NAME', 'default': 'ImageBed', 'type': 'str', 'group': 'Site', 'label': 'Site Name', 'secret': False},
    'allow_register': {'env': 'ALLOW_REGISTER', 'default': 'true', 'type': 'bool', 'group': 'Site', 'label': 'Allow Public Registration', 'secret': False},
}

SETTING_KEYS = list(SCHEMA.keys())


class ConfigManager:
    __slots__ = ('db', '_cache')

    def __init__(self, db):
        self.db = db
        self._cache = {}
        self.reload()

    def reload(self):
        rows = self.db.fetchall('SELECT key, value FROM config')
        self._cache = {row['key']: row['value'] for row in rows}

    def get(self, key, default=None):
        if key in self._cache:
            return self._cache[key]
        spec = SCHEMA.get(key)
        env_name = spec['env'] if spec else key.upper()
        env_value = os.environ.get(env_name)
        if env_value is not None:
            return env_value
        if default is not None:
            return default
        return spec['default'] if spec else ''

    def get_int(self, key, default=0):
        try:
            return int(float(self.get(key, default)))
        except (TypeError, ValueError):
            return default

    def get_float(self, key, default=0.0):
        try:
            return float(self.get(key, default))
        except (TypeError, ValueError):
            return default

    def get_bool(self, key, default=False):
        value = self.get(key, str(default)).strip().lower()
        return value in ('1', 'true', 'yes', 'on')

    def set(self, key, value):
        self.db.set_config(key, str(value))
        self._cache[key] = str(value)

    def public_schema(self):
        out = []
        for key in SETTING_KEYS:
            spec = SCHEMA[key]
            item = {
                'key': key,
                'env': spec['env'],
                'type': spec['type'],
                'group': spec['group'],
                'label': spec['label'],
                'secret': spec['secret'],
            }
            if 'options' in spec:
                item['options'] = spec['options']
            out.append(item)
        return out

    def public_values(self):
        out = {}
        for key in SETTING_KEYS:
            spec = SCHEMA[key]
            value = self.get(key)
            if spec['secret'] and value:
                out[key] = MASKED
            else:
                out[key] = value
        return out
