import json
import time

from utils.cost import CostCalculator


class BudgetEnforcer:
    __slots__ = ('db', 'cost_calc', 'last_check', 'current_status', 'disabled_modules')

    def __init__(self, db, config=None):
        self.db = db
        self.cost_calc = CostCalculator(config)
        self.last_check = 0
        self.current_status = 'normal'
        self.disabled_modules = set()

    def check(self):
        now = time.time()
        if now - self.last_check < 60:
            return self.current_status
        self.last_check = now
        self.current_status = self.cost_calc.get_budget_status()

        if self.current_status == 'emergency':
            self.disabled_modules = {'admin', 'scheduler', 'server_link', 'budget'}
        elif self.current_status == 'warning':
            self.disabled_modules = {'scheduler', 'server_link'}
        else:
            self.disabled_modules = set()

        return self.current_status

    def is_module_enabled(self, module_name):
        return module_name not in self.disabled_modules

    def enforce(self, handler, module_name):
        status = self.check()
        if not self.is_module_enabled(module_name):
            handler.send_response(503)
            handler.send_header('Content-Type', 'application/json')
            handler.end_headers()
            handler.wfile.write(json.dumps({
                'error': 'Module disabled due to budget constraints',
                'status': status
            }).encode())
            return False
        return True
