import json
import os
import traceback

from modules.user import UserModule
from modules.imagebed import ImageBedModule
from modules.admin import AdminModule
from modules.budget import BudgetModule
from modules.mini_ui import MiniUIModule
from modules.scheduler import SchedulerModule
from modules.server_link import ServerLinkModule
from modules.storage import StorageManager
from utils.config import ConfigManager
from utils.cost import CostCalculator
from utils.ratelimit import rate_limiter
from utils.budget_enforcer import BudgetEnforcer

STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static')


class Router:
    __slots__ = ('db', 'auth', 'config', 'storage', 'cost_calc', 'budget_enforcer', 'user_mod',
                 'imagebed_mod', 'admin_mod', 'budget_mod', 'mini_ui_mod', 'scheduler_mod', 'server_link_mod')

    def __init__(self, db, auth):
        self.db = db
        self.auth = auth
        self.config = ConfigManager(db)
        self.storage = StorageManager(self.config)
        self.cost_calc = CostCalculator(self.config)
        self.budget_enforcer = BudgetEnforcer(db, self.config)
        rate_limiter.configure(self.config)
        self.user_mod = UserModule(db, auth, self.config)
        self.imagebed_mod = ImageBedModule(db, auth, self.config, self.storage)
        self.admin_mod = AdminModule(db, auth, self.config, self.storage)
        self.budget_mod = BudgetModule(db, auth, self.config)
        self.mini_ui_mod = MiniUIModule(db, auth, self.config)
        self.scheduler_mod = SchedulerModule(db, auth, self.config)
        self.server_link_mod = ServerLinkModule(db, auth, self.config)

    def route(self, handler, method):
        try:
            self._check_rate_limit(handler)
            self._route_inner(handler, method)
        except Exception as e:
            self._handle_error(handler, e)

    def _route_inner(self, handler, method):
        path = handler.path

        if path == '/health':
            self._send_json(handler, 200, {'status': 'ok'})
            return

        if path == '/budget/status':
            self._send_json(handler, 200, self.budget_mod.get_status())
            return

        if path == '/mini':
            if not self.budget_enforcer.enforce(handler, 'mini_ui'):
                return
            self.mini_ui_mod.handle(handler, method)
            return

        if path.startswith('/api/user/'):
            if not self.budget_enforcer.enforce(handler, 'user'):
                return
            self.user_mod.handle(handler, method, path)
            return

        if path.startswith('/api/admin/'):
            if not self.budget_enforcer.enforce(handler, 'admin'):
                return
            self.admin_mod.handle(handler, method, path)
            return

        if path.startswith('/api/budget/'):
            if not self.budget_enforcer.enforce(handler, 'budget'):
                return
            self.budget_mod.handle(handler, method, path)
            return

        if path.startswith('/api/scheduler/'):
            if not self.budget_enforcer.enforce(handler, 'scheduler'):
                return
            self.scheduler_mod.handle(handler, method, path)
            return

        if path == '/api/servers' or path.startswith('/api/servers/'):
            if not self.budget_enforcer.enforce(handler, 'server_link'):
                return
            self.server_link_mod.handle(handler, method, path)
            return

        if path.startswith('/f/'):
            self.imagebed_mod.handle_public(handler, method, path)
            return

        if path.startswith('/api/upload') or path.startswith('/api/files'):
            if not self.budget_enforcer.enforce(handler, 'imagebed'):
                return
            self.imagebed_mod.handle(handler, method, path)
            return

        if path == '/' or path == '/index.html':
            self._serve_static(handler, 'index.html')
            return

        if path == '/admin' or path == '/admin.html':
            self._serve_static(handler, 'admin.html')
            return

        self._serve_static(handler, 'index.html')

    def _check_rate_limit(self, handler):
        client = handler.client_address[0]
        if not rate_limiter.is_allowed(client):
            handler.send_response(429)
            handler.send_header('Content-Type', 'application/json')
            handler.end_headers()
            handler.wfile.write(json.dumps({'error': 'Rate limit exceeded'}).encode())
            raise Exception('Rate limit exceeded')

    def _handle_error(self, handler, e):
        try:
            if str(e) == 'Rate limit exceeded':
                return
            traceback.print_exc()
            handler.send_response(500)
            handler.send_header('Content-Type', 'application/json')
            handler.end_headers()
            handler.wfile.write(json.dumps({'error': 'Internal server error'}).encode())
        except Exception:
            pass

    def _serve_static(self, handler, filename):
        filepath = os.path.join(STATIC_DIR, filename)
        if os.path.exists(filepath):
            with open(filepath, 'rb') as f:
                content = f.read()
            self._send_response(handler, 200, content, 'text/html; charset=utf-8')
        else:
            self._send_json(handler, 404, {'error': 'Not found'})

    def _send_json(self, handler, status, data):
        body = json.dumps(data).encode()
        handler.send_response(status)
        handler.send_header('Content-Type', 'application/json')
        handler.send_header('Content-Length', str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)

    def _send_response(self, handler, status, body, content_type):
        handler.send_response(status)
        handler.send_header('Content-Type', content_type)
        handler.send_header('Content-Length', str(len(body)))
        handler.send_header('Cache-Control', 'no-cache')
        handler.end_headers()
        handler.wfile.write(body)
