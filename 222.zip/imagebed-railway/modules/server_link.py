import json
from modules.base import BaseModule


class ServerLinkModule(BaseModule):
    __slots__ = ()

    def handle(self, handler, method, path):
        if path == '/api/servers' and method == 'GET':
            self.list_servers(handler)
        elif path == '/api/servers' and method == 'POST':
            self.add_server(handler)
        elif path.startswith('/api/servers/') and method == 'DELETE':
            self.delete_server(handler, path)
        else:
            handler.send_response(404)
            handler.end_headers()

    def list_servers(self, handler):
        servers = self.db.get_servers()
        self._send_json(handler, 200, {'servers': [dict(s) for s in servers]})

    def add_server(self, handler):
        data = self._read_body(handler)
        if data is None:
            return
        name = data.get('name', '').strip()
        url = data.get('url', '').strip()
        auth_token = data.get('auth_token', '')
        role = data.get('role', 'peer')

        if not name or not url or not auth_token:
            self._send_error(handler, 400, 'Name, URL and auth token required')
            return

        if role not in ('master', 'slave', 'peer'):
            self._send_error(handler, 400, 'Invalid role')
            return

        self.db.add_server(name, url, auth_token, role)
        self._send_json(handler, 201, {'added': True})

    def delete_server(self, handler, path):
        try:
            server_id = int(path.split('/api/servers/')[-1])
        except (ValueError, IndexError):
            self._send_error(handler, 400, 'Invalid server ID')
            return

        self.db.execute('DELETE FROM servers WHERE id = ?', (server_id,))
        self._send_json(handler, 200, {'deleted': True})
