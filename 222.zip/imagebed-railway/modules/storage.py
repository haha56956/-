import json
import os
import io


class StorageManager:
    __slots__ = ('config', 'backend', 'backend_type', 'last_error')

    def __init__(self, config):
        self.config = config
        self.backend = None
        self.backend_type = 'none'
        self.last_error = ''
        self.reload()

    def reload(self):
        self.backend = None
        self.last_error = ''
        backend_type = (self.config.get('storage_type', 'none') or 'none').strip().lower()
        self.backend_type = backend_type

        if backend_type in ('', 'none'):
            return

        try:
            if backend_type == 'redis':
                url = self.config.get('redis_url', '')
                if not url:
                    self.last_error = 'Redis URL not configured'
                    return
                self.backend = RedisBackend(url)
            elif backend_type == 'tidb':
                host = self.config.get('tidb_host', '')
                if not host:
                    self.last_error = 'TiDB host not configured'
                    return
                self.backend = TiDBBackend(
                    host,
                    self.config.get_int('tidb_port', 4000),
                    self.config.get('tidb_user', 'root'),
                    self.config.get('tidb_password', ''),
                    self.config.get('tidb_database', 'imagebed')
                )
            elif backend_type == 's3':
                import boto3
                self.backend = boto3.client(
                    's3',
                    endpoint_url=self.config.get('s3_endpoint') or None,
                    aws_access_key_id=self.config.get('s3_access_key') or None,
                    aws_secret_access_key=self.config.get('s3_secret_key') or None,
                    region_name=self.config.get('s3_region') or 'us-east-1'
                )
            elif backend_type == 'alist':
                url = self.config.get('alist_url', '')
                if not url:
                    self.last_error = 'Alist URL not configured'
                    return
                self.backend = AlistBackend(url, self.config.get('alist_token', ''))
            elif backend_type == 'ftp':
                host = self.config.get('ftp_host', '')
                if not host:
                    self.last_error = 'FTP host not configured'
                    return
                self.backend = FTPBackend(host, self.config.get_int('ftp_port', 21),
                                          self.config.get('ftp_user', ''), self.config.get('ftp_pass', ''))
            elif backend_type == 'oss':
                import oss2
                auth = oss2.Auth(self.config.get('oss_access_key', ''), self.config.get('oss_secret_key', ''))
                self.backend = oss2.Bucket(auth, self.config.get('oss_endpoint', ''), self.config.get('oss_bucket', ''))
            else:
                self.last_error = f'Unknown storage backend: {backend_type}'
        except ImportError as e:
            self.last_error = f'Missing dependency: {e}'
        except Exception as e:
            self.last_error = str(e)

    def get_backend_type(self):
        return self.backend_type

    def upload(self, path, data):
        if not self.backend:
            return False
        try:
            if self.backend_type in ('redis', 'tidb', 'alist', 'ftp'):
                return self.backend.upload(path, data)
            if self.backend_type == 's3':
                self.backend.put_object(Bucket=self.config.get('s3_bucket', ''), Key=path, Body=data)
                return True
            if self.backend_type == 'oss':
                self.backend.put_object(path, data)
                return True
        except Exception as e:
            self.last_error = str(e)
            return False
        return False

    def download(self, path):
        if not self.backend:
            return None
        try:
            if self.backend_type in ('redis', 'tidb', 'alist', 'ftp'):
                return self.backend.download(path)
            if self.backend_type == 's3':
                resp = self.backend.get_object(Bucket=self.config.get('s3_bucket', ''), Key=path)
                return resp['Body'].read()
            if self.backend_type == 'oss':
                return self.backend.get_object(path).read()
        except Exception as e:
            self.last_error = str(e)
            return None
        return None

    def delete(self, path):
        if not self.backend:
            return False
        try:
            if self.backend_type in ('redis', 'tidb', 'alist', 'ftp'):
                return self.backend.delete(path)
            if self.backend_type == 's3':
                self.backend.delete_object(Bucket=self.config.get('s3_bucket', ''), Key=path)
                return True
            if self.backend_type == 'oss':
                self.backend.delete_object(path)
                return True
        except Exception as e:
            self.last_error = str(e)
            return False
        return False

    def check(self):
        backend_type = self.backend_type
        if backend_type in ('', 'none'):
            return False, 'No storage backend configured'
        if not self.backend:
            return False, self.last_error or 'Backend not initialized'
        try:
            if backend_type == 'redis':
                self.backend.client.ping()
                return True, 'Redis connection OK'
            if backend_type == 'tidb':
                conn, cursor = self.backend._get_conn()
                cursor.close()
                conn.close()
                return True, 'TiDB connection OK'
            if backend_type == 's3':
                self.backend.head_bucket(Bucket=self.config.get('s3_bucket', ''))
                return True, 'S3 bucket reachable'
            if backend_type == 'alist':
                import urllib.request
                url = self.backend.url + '/api/fs/list'
                payload = json.dumps({'path': '/', 'password': '', 'page': 1, 'per_page': 1}).encode()
                req = urllib.request.Request(url, data=payload, method='POST')
                req.add_header('Authorization', self.backend.token)
                req.add_header('Content-Type', 'application/json')
                urllib.request.urlopen(req, timeout=15)
                return True, 'Alist reachable'
            if backend_type == 'ftp':
                ftp = self.backend._connect()
                ftp.quit()
                return True, 'FTP connection OK'
            if backend_type == 'oss':
                self.backend.get_bucket_info()
                return True, 'OSS bucket reachable'
        except Exception as e:
            return False, str(e)
        return False, 'Unknown storage backend'


class RedisBackend:
    __slots__ = ('client',)

    def __init__(self, url):
        import redis
        self.client = redis.from_url(url, decode_responses=False)

    def upload(self, path, data):
        try:
            self.client.set(f'file:{path}', data)
            return True
        except Exception:
            return False

    def download(self, path):
        try:
            return self.client.get(f'file:{path}')
        except Exception:
            return None

    def delete(self, path):
        try:
            self.client.delete(f'file:{path}')
            return True
        except Exception:
            return False


class TiDBBackend:
    __slots__ = ('config',)

    def __init__(self, host, port, user, password, database):
        self.config = {
            'host': host,
            'port': port,
            'user': user,
            'password': password,
            'database': database,
            'charset': 'utf8mb4'
        }

    def _get_conn(self):
        import pymysql
        conn = pymysql.connect(**self.config)
        cursor = conn.cursor()
        cursor.execute('CREATE TABLE IF NOT EXISTS files (path VARCHAR(512) PRIMARY KEY, data LONGBLOB, size INT, uploaded INT)')
        conn.commit()
        return conn, cursor

    def upload(self, path, data):
        try:
            conn, cursor = self._get_conn()
            cursor.execute(
                'INSERT INTO files (path, data, size, uploaded) VALUES (%s, %s, %s, %s) ON DUPLICATE KEY UPDATE data=%s, size=%s, uploaded=%s',
                (path, data, len(data), int(__import__('time').time()), data, len(data), int(__import__('time').time()))
            )
            conn.commit()
            cursor.close()
            conn.close()
            return True
        except Exception:
            return False

    def download(self, path):
        try:
            conn, cursor = self._get_conn()
            cursor.execute('SELECT data FROM files WHERE path = %s', (path,))
            row = cursor.fetchone()
            cursor.close()
            conn.close()
            return row[0] if row else None
        except Exception:
            return None

    def delete(self, path):
        try:
            conn, cursor = self._get_conn()
            cursor.execute('DELETE FROM files WHERE path = %s', (path,))
            conn.commit()
            cursor.close()
            conn.close()
            return True
        except Exception:
            return False


class AlistBackend:
    __slots__ = ('url', 'token')

    def __init__(self, url, token):
        self.url = url.rstrip('/')
        self.token = token

    def upload(self, path, data):
        import urllib.request
        url = f'{self.url}/api/fs/put'
        req = urllib.request.Request(url, data=data, method='PUT')
        req.add_header('Authorization', self.token)
        req.add_header('File-Path', '/' + path)
        try:
            resp = urllib.request.urlopen(req, timeout=30)
            return resp.status == 200
        except Exception:
            return False

    def download(self, path):
        import urllib.request
        url = f'{self.url}/d/{path}'
        req = urllib.request.Request(url)
        req.add_header('Authorization', self.token)
        try:
            resp = urllib.request.urlopen(req, timeout=30)
            return resp.read()
        except Exception:
            return None

    def delete(self, path):
        import urllib.request
        url = f'{self.url}/api/fs/delete'
        req = urllib.request.Request(url, json.dumps({'names': [path]}).encode(), method='POST')
        req.add_header('Authorization', self.token)
        req.add_header('Content-Type', 'application/json')
        try:
            resp = urllib.request.urlopen(req, timeout=30)
            return resp.status == 200
        except Exception:
            return False


class FTPBackend:
    __slots__ = ('host', 'port', 'user', 'passwd')

    def __init__(self, host, port, user, passwd):
        self.host = host
        self.port = port
        self.user = user
        self.passwd = passwd

    def _connect(self):
        from ftplib import FTP
        ftp = FTP()
        ftp.connect(self.host, self.port, timeout=30)
        ftp.login(self.user, self.passwd)
        return ftp

    def upload(self, path, data):
        ftp = self._connect()
        try:
            dirs = path.split('/')[:-1]
            for d in dirs:
                try:
                    ftp.cwd(d)
                except Exception:
                    ftp.mkd(d)
                    ftp.cwd(d)
            ftp.storbinary('STOR ' + path.split('/')[-1], io.BytesIO(data))
            return True
        except Exception:
            return False
        finally:
            try:
                ftp.quit()
            except Exception:
                ftp.close()

    def download(self, path):
        ftp = self._connect()
        try:
            buf = io.BytesIO()
            ftp.retrbinary('RETR ' + path, buf.write)
            return buf.getvalue()
        except Exception:
            return None
        finally:
            try:
                ftp.quit()
            except Exception:
                ftp.close()

    def delete(self, path):
        ftp = self._connect()
        try:
            ftp.delete(path)
            return True
        except Exception:
            return False
        finally:
            try:
                ftp.quit()
            except Exception:
                ftp.close()
