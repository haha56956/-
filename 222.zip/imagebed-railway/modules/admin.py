from modules.base import BaseModule
from utils.config import SCHEMA, MASKED

BOOL_VALUES = ('1', '0', 'true', 'false', 'yes', 'no', 'on', 'off')


class AdminModule(BaseModule):
    __slots__ = ('storage',)

    def __init__(self, db, auth, config, storage):
        super().__init__(db, auth, config)
        self.storage = storage

    def handle(self, handler, method, path):
        user = self._authenticate_admin(handler)
        if not user:
            return

        if path == '/api/admin/users' and method == 'GET':
            self.list_users(handler)
        elif path == '/api/admin/users' and method == 'POST':
            self.create_user(handler)
        elif path.startswith('/api/admin/users/') and method == 'PUT':
            self.update_user(handler, path)
        elif path.startswith('/api/admin/users/') and method == 'DELETE':
            self.delete_user(handler, path)
        elif path == '/api/admin/groups' and method == 'GET':
            self.list_groups(handler)
        elif path == '/api/admin/groups' and method == 'POST':
            self.create_group(handler)
        elif path.startswith('/api/admin/groups/') and method == 'PUT':
            self.update_group(handler, path)
        elif path.startswith('/api/admin/groups/') and method == 'DELETE':
            self.delete_group(handler, path)
        elif path == '/api/admin/settings' and method == 'GET':
            self.get_settings(handler)
        elif path == '/api/admin/settings' and method == 'PUT':
            self.update_settings(handler)
        elif path == '/api/admin/settings/test' and method == 'POST':
            self.test_storage(handler)
        elif path == '/api/admin/password' and method == 'POST':
            self.change_password(handler, user)
        elif path == '/api/admin/config' and method == 'GET':
            self.get_config(handler)
        elif path == '/api/admin/config' and method == 'PUT':
            self.update_config(handler)
        elif path == '/api/admin/stats' and method == 'GET':
            self.get_stats(handler)
        else:
            handler.send_response(404)
            handler.end_headers()

    def list_users(self, handler):
        users = self.db.get_all_users()
        self._send_json(handler, 200, {'users': [dict(u) for u in users]})

    def create_user(self, handler):
        data = self._read_body(handler)
        if data is None:
            return
        username = data.get('username', '').strip()
        password = data.get('password', '')
        role = data.get('role', 'user')
        group_id = data.get('group_id', 1)

        if not username or not password:
            self._send_error(handler, 400, 'Username and password required')
            return

        if role not in ('admin', 'user'):
            self._send_error(handler, 400, 'Invalid role')
            return

        existing = self.db.get_user(username)
        if existing:
            self._send_error(handler, 409, 'Username already exists')
            return

        password_hash = self.auth.hash_password(password)
        user = self.db.create_user(username, password_hash, role, group_id)
        self._send_json(handler, 201, {
            'id': user['id'],
            'username': user['username'],
            'role': user['role']
        })

    def update_user(self, handler, path):
        data = self._read_body(handler)
        if data is None:
            return
        try:
            user_id = int(path.split('/api/admin/users/')[-1])
        except (ValueError, IndexError):
            self._send_error(handler, 400, 'Invalid user ID')
            return

        user = self.db.get_user_by_id(user_id)
        if not user:
            self._send_error(handler, 404, 'User not found')
            return

        storage_quota = data.get('storage_quota', user['storage_quota'])
        file_count_limit = data.get('file_count_limit', user['file_count_limit'])

        if not isinstance(storage_quota, int) or storage_quota < 0:
            self._send_error(handler, 400, 'Invalid storage quota')
            return
        if not isinstance(file_count_limit, int) or file_count_limit < 0:
            self._send_error(handler, 400, 'Invalid file count limit')
            return

        self.db.update_user_quota(user_id, storage_quota, file_count_limit)
        self._send_json(handler, 200, {'updated': True})

    def delete_user(self, handler, path):
        try:
            user_id = int(path.split('/api/admin/users/')[-1])
        except (ValueError, IndexError):
            self._send_error(handler, 400, 'Invalid user ID')
            return

        user = self.db.get_user_by_id(user_id)
        if not user:
            self._send_error(handler, 404, 'User not found')
            return

        if user['role'] == 'admin':
            self._send_error(handler, 403, 'Cannot delete admin user')
            return

        self.db.delete_user(user_id)
        self._send_json(handler, 200, {'deleted': True})

    def list_groups(self, handler):
        groups = self.db.get_all_groups()
        self._send_json(handler, 200, {'groups': [dict(g) for g in groups]})

    def create_group(self, handler):
        data = self._read_body(handler)
        if data is None:
            return
        name = data.get('name', '').strip()
        storage_quota = data.get('storage_quota', 104857600)
        file_count_limit = data.get('file_count_limit', 100)

        if not name:
            self._send_error(handler, 400, 'Group name required')
            return

        self.db.create_group(name, storage_quota, file_count_limit)
        self._send_json(handler, 201, {'created': True})

    def update_group(self, handler, path):
        data = self._read_body(handler)
        if data is None:
            return
        try:
            group_id = int(path.split('/api/admin/groups/')[-1])
        except (ValueError, IndexError):
            self._send_error(handler, 400, 'Invalid group ID')
            return

        storage_quota = data.get('storage_quota', 104857600)
        file_count_limit = data.get('file_count_limit', 100)
        self.db.update_group(group_id, storage_quota, file_count_limit)
        self._send_json(handler, 200, {'updated': True})

    def delete_group(self, handler, path):
        try:
            group_id = int(path.split('/api/admin/groups/')[-1])
        except (ValueError, IndexError):
            self._send_error(handler, 400, 'Invalid group ID')
            return

        if group_id == 1:
            self._send_error(handler, 403, 'Cannot delete default group')
            return

        self.db.delete_group(group_id)
        self._send_json(handler, 200, {'deleted': True})

    def get_settings(self, handler):
        self._send_json(handler, 200, {
            'settings': self.config.public_values(),
            'schema': self.config.public_schema()
        })

    def update_settings(self, handler):
        data = self._read_body(handler, max_size=65536)
        if data is None:
            return
        if not isinstance(data, dict):
            self._send_error(handler, 400, 'Invalid payload')
            return

        errors = []
        for key, value in data.items():
            spec = SCHEMA.get(key)
            if spec is None:
                continue
            text = '' if value is None else str(value)
            if spec['secret'] and text == MASKED:
                continue
            if spec['type'] == 'int':
                try:
                    int(float(text))
                except (TypeError, ValueError):
                    errors.append(key)
                    continue
            elif spec['type'] == 'float':
                try:
                    float(text)
                except (TypeError, ValueError):
                    errors.append(key)
                    continue
            elif spec['type'] == 'bool':
                if text.strip().lower() not in BOOL_VALUES:
                    errors.append(key)
                    continue
            if 'options' in spec and text not in spec['options']:
                errors.append(key)
                continue
            self.config.set(key, text)

        if self.storage:
            self.storage.reload()
        self._send_json(handler, 200, {'updated': True, 'errors': errors})

    def test_storage(self, handler):
        if not self.storage:
            self._send_error(handler, 500, 'Storage manager unavailable')
            return
        self.storage.reload()
        ok, message = self.storage.check()
        self._send_json(handler, 200, {'ok': ok, 'message': message})

    def change_password(self, handler, user):
        data = self._read_body(handler)
        if data is None:
            return
        old_password = data.get('old_password', '')
        new_password = data.get('new_password', '')

        if not self.auth.verify_password(user['password_hash'], old_password):
            self._send_error(handler, 401, 'Current password is incorrect')
            return
        if len(new_password) < 6:
            self._send_error(handler, 400, 'New password must be at least 6 characters')
            return

        self.db.execute('UPDATE users SET password_hash = ? WHERE id = ?',
                        (self.auth.hash_password(new_password), user['id']))
        self._send_json(handler, 200, {'updated': True})

    def get_config(self, handler):
        self._send_json(handler, 200, {'config': {
            'daily_budget': self.config.get('daily_budget'),
            'total_storage_limit': self.config.get('total_storage_limit'),
            'storage_type': self.config.get('storage_type')
        }})

    def update_config(self, handler):
        data = self._read_body(handler)
        if data is None:
            return
        for key in ('daily_budget', 'total_storage_limit', 'storage_type'):
            if key in data:
                self.config.set(key, data[key])
        if self.storage:
            self.storage.reload()
        self._send_json(handler, 200, {'updated': True})

    def get_stats(self, handler):
        users = self.db.get_all_users()
        total_storage = self.db.get_total_storage_used()
        self._send_json(handler, 200, {
            'total_users': len(users),
            'total_storage_used': total_storage,
            'total_storage_limit': self.config.get('total_storage_limit')
        })
