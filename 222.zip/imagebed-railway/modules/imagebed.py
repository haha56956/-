import uuid
import time
from modules.base import BaseModule

IMAGE_TYPES = ('png', 'jpeg', 'gif', 'webp')


class ImageBedModule(BaseModule):
    __slots__ = ('storage',)

    def __init__(self, db, auth, config, storage):
        super().__init__(db, auth, config)
        self.storage = storage

    def handle(self, handler, method, path):
        if path == '/api/upload' and method == 'POST':
            self.upload(handler)
        elif path == '/api/files' and method == 'GET':
            self.list_files(handler)
        elif path.startswith('/api/files/') and method == 'DELETE':
            self.delete(handler, path)
        else:
            handler.send_response(404)
            handler.end_headers()

    def handle_public(self, handler, method, path):
        token = path.split('/f/')[-1] if '/f/' in path else ''
        if not token:
            handler.send_response(404)
            handler.end_headers()
            return

        file = self.db.get_file_by_token(token)
        if not file:
            handler.send_response(404)
            handler.end_headers()
            return

        content = self.storage.download(file['storage_path'])
        if content is None:
            handler.send_response(404)
            handler.end_headers()
            return

        file_type = file['file_type'] or 'other'
        if file_type == 'html':
            content_type = 'text/html; charset=utf-8'
        elif file_type in IMAGE_TYPES:
            content_type = 'image/' + file_type
        else:
            content_type = 'application/octet-stream'

        handler.send_response(200)
        handler.send_header('Content-Type', content_type)
        handler.send_header('Content-Length', str(len(content)))
        handler.send_header('Cache-Control', 'public, max-age=31536000')
        handler.end_headers()
        handler.wfile.write(content)

    def upload(self, handler):
        user = self._authenticate(handler)
        if not user:
            return

        content_type = handler.headers.get('Content-Type', '')
        if not content_type.startswith('multipart/form-data'):
            self._send_error(handler, 400, 'Multipart form data required')
            return

        max_upload_size = self.config.get_int('max_upload_size', 10485760) if self.config else 10485760

        stats = self.db.get_user_stats(user['id'])
        if stats['file_count'] >= user['file_count_limit']:
            self._send_error(handler, 403, 'File count limit reached')
            return

        length = int(handler.headers.get('Content-Length', 0))
        if length == 0:
            self._send_error(handler, 400, 'Empty request body')
            return
        if length > max_upload_size:
            self._send_error(handler, 413, 'File too large')
            return

        body = handler.rfile.read(length)
        boundary = content_type.split('boundary=')[-1].encode()
        parts = body.split(b'--' + boundary)

        file_data = None
        filename = None
        file_type = None

        for part in parts:
            if b'Content-Disposition' in part and b'filename=' in part:
                headers_end = part.find(b'\r\n\r\n')
                if headers_end == -1:
                    continue
                headers = part[:headers_end].decode('utf-8', errors='ignore')
                data = part[headers_end + 4:]
                if data.endswith(b'\r\n'):
                    data = data[:-2]

                for h in headers.split('\r\n'):
                    if 'filename="' in h:
                        filename = h.split('filename="')[1].split('"')[0]
                    if 'Content-Type:' in h:
                        ct = h.split('Content-Type:')[1].strip()
                        if 'html' in ct:
                            file_type = 'html'
                        elif 'png' in ct:
                            file_type = 'png'
                        elif 'jpeg' in ct or 'jpg' in ct:
                            file_type = 'jpeg'
                        elif 'gif' in ct:
                            file_type = 'gif'
                        elif 'webp' in ct:
                            file_type = 'webp'
                        else:
                            file_type = 'other'

                file_data = data
                break

        if file_data is None:
            self._send_error(handler, 400, 'No file found in request')
            return

        if filename:
            filename = filename.replace('\\', '/').split('/')[-1].strip().lstrip('.')
        if not filename:
            filename = str(uuid.uuid4())
        if file_type is None:
            file_type = 'other'

        if stats['total_size'] + len(file_data) > user['storage_quota']:
            self._send_error(handler, 403, 'Storage quota exceeded')
            return

        if self.config:
            total_limit = self.config.get_int('total_storage_limit', 524288000)
            if self.db.get_total_storage_used() + len(file_data) > total_limit:
                self._send_error(handler, 507, 'Server storage capacity reached')
                return

        file_id = str(uuid.uuid4())
        storage_path = f"{user['id']}/{file_id}/{filename}"
        backend = self.storage.get_backend_type()

        if not self.storage.upload(storage_path, file_data):
            self._send_error(handler, 500, 'Upload failed')
            return

        access_token = self.auth.generate_access_token()
        self.db.add_file(user['id'], file_id, filename, file_type, len(file_data), backend, storage_path, access_token)

        self._send_json(handler, 201, {
            'id': file_id,
            'filename': filename,
            'size': len(file_data),
            'type': file_type,
            'url': f'/f/{access_token}',
            'created_at': time.time()
        })

    def list_files(self, handler):
        user = self._authenticate(handler)
        if not user:
            return

        files = self.db.get_user_files(user['id'])
        self._send_json(handler, 200, {'files': [dict(f) for f in files]})

    def delete(self, handler, path):
        user = self._authenticate(handler)
        if not user:
            return

        try:
            file_id = int(path.split('/api/files/')[-1])
        except (ValueError, IndexError):
            self._send_error(handler, 400, 'Invalid file ID')
            return

        file = self.db.get_file_by_id(file_id)
        if not file or file['user_id'] != user['id']:
            self._send_error(handler, 404, 'File not found')
            return

        self.storage.delete(file['storage_path'])
        self.db.delete_file(file['id'])
        self._send_json(handler, 200, {'deleted': True})
