import json


class BaseModule:
    __slots__ = ('db', 'auth', 'config')

    def __init__(self, db, auth=None, config=None):
        self.db = db
        self.auth = auth
        self.config = config

    def _read_body(self, handler, max_size=1048576):
        length = int(handler.headers.get('Content-Length', 0))
        if length > max_size:
            self._send_error(handler, 413, 'Payload too large')
            return None
        if length > 0:
            try:
                return json.loads(handler.rfile.read(length))
            except (json.JSONDecodeError, ValueError):
                self._send_error(handler, 400, 'Invalid JSON')
                return None
        return {}

    def _authenticate(self, handler):
        auth_header = handler.headers.get('Authorization', '')
        if not auth_header.startswith('Bearer '):
            self._send_error(handler, 401, 'Missing token')
            return None

        token = auth_header[7:]
        payload = self.auth.verify_token(token)
        if not payload:
            self._send_error(handler, 401, 'Invalid token')
            return None

        user = self.db.get_user_by_id(payload['uid'])
        if not user:
            self._send_error(handler, 401, 'User not found')
            return None

        return user

    def _authenticate_admin(self, handler):
        user = self._authenticate(handler)
        if not user:
            return None
        if user['role'] != 'admin':
            self._send_error(handler, 403, 'Admin access required')
            return None
        return user

    def _send_json(self, handler, status, data):
        body = json.dumps(data).encode()
        handler.send_response(status)
        handler.send_header('Content-Type', 'application/json')
        handler.send_header('Content-Length', str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)

    def _send_error(self, handler, status, message):
        self._send_json(handler, status, {'error': message})
