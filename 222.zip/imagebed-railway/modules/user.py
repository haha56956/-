from modules.base import BaseModule


class UserModule(BaseModule):
    __slots__ = ()

    def handle(self, handler, method, path):
        if path == '/api/user/register' and method == 'POST':
            self.register(handler)
        elif path == '/api/user/login' and method == 'POST':
            self.login(handler)
        elif path == '/api/user/profile' and method == 'GET':
            self.profile(handler)
        elif path == '/api/user/files' and method == 'GET':
            self.list_files(handler)
        else:
            handler.send_response(404)
            handler.end_headers()

    def register(self, handler):
        if self.config and not self.config.get_bool('allow_register', True):
            self._send_error(handler, 403, 'Registration is disabled')
            return

        data = self._read_body(handler)
        if data is None:
            return
        username = data.get('username', '').strip()
        password = data.get('password', '')

        if not username or not password:
            self._send_error(handler, 400, 'Username and password required')
            return

        if len(username) < 3 or len(username) > 32:
            self._send_error(handler, 400, 'Username must be 3-32 characters')
            return

        if len(password) < 6:
            self._send_error(handler, 400, 'Password must be at least 6 characters')
            return

        existing = self.db.get_user(username)
        if existing:
            self._send_error(handler, 409, 'Username already exists')
            return

        password_hash = self.auth.hash_password(password)
        user = self.db.create_user(username, password_hash)
        self._send_json(handler, 201, {
            'id': user['id'],
            'username': user['username'],
            'role': user['role']
        })

    def login(self, handler):
        data = self._read_body(handler)
        if data is None:
            return
        username = data.get('username', '')
        password = data.get('password', '')

        user = self.db.get_user(username)
        if not user or not self.auth.verify_password(user['password_hash'], password):
            self._send_error(handler, 401, 'Invalid credentials')
            return

        token = self.auth.generate_token(user['id'], user['username'], user['role'])
        self._send_json(handler, 200, {
            'token': token,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'role': user['role']
            }
        })

    def profile(self, handler):
        user = self._authenticate(handler)
        if not user:
            return

        stats = self.db.get_user_stats(user['id'])
        self._send_json(handler, 200, {
            'id': user['id'],
            'username': user['username'],
            'role': user['role'],
            'group_id': user['group_id'],
            'storage_quota': user['storage_quota'],
            'file_count_limit': user['file_count_limit'],
            'used_storage': stats['total_size'],
            'file_count': stats['file_count']
        })

    def list_files(self, handler):
        user = self._authenticate(handler)
        if not user:
            return

        files = self.db.get_user_files(user['id'])
        self._send_json(handler, 200, {'files': [dict(f) for f in files]})
