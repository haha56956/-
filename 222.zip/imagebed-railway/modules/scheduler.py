import json
import time
from modules.base import BaseModule


class SchedulerModule(BaseModule):
    __slots__ = ()

    def handle(self, handler, method, path):
        if path == '/api/scheduler/analyze' and method == 'POST':
            self.analyze(handler)
        elif path == '/api/scheduler/report' and method == 'GET':
            self.report(handler)
        else:
            handler.send_response(404)
            handler.end_headers()

    def analyze(self, handler):
        since = time.time() - (7 * 86400)
        hourly_stats = self.db.get_hourly_stats(since)

        hourly = {}
        for row in hourly_stats:
            hour = row['hour']
            hourly[hour] = hourly.get(hour, 0) + row['count']

        sorted_hours = sorted(hourly.items(), key=lambda x: x[1], reverse=True)
        peak_hours = [h[0] for h in sorted_hours[:5]]
        off_hours = [h[0] for h in sorted_hours[-5:]]

        result = {
            'peak_hours': peak_hours,
            'off_hours': off_hours,
            'hourly_distribution': {str(h): c for h, c in hourly.items()},
            'analyzed_at': time.time()
        }

        self._send_json(handler, 200, result)

    def report(self, handler):
        since = time.time() - (7 * 86400)
        stats = self.db.get_access_stats(since)

        self._send_json(handler, 200, {
            'period': '7d',
            'module_stats': {row['module']: row['count'] for row in stats}
        })
