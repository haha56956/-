import json
import time
from modules.base import BaseModule
from utils.cost import CostCalculator


class BudgetModule(BaseModule):
    __slots__ = ()

    def handle(self, handler, method, path):
        if path == '/api/budget/estimate' and method == 'GET':
            self.estimate(handler)
        elif path == '/api/budget/history' and method == 'GET':
            self.history(handler)
        else:
            handler.send_response(404)
            handler.end_headers()

    def get_status(self):
        calc = CostCalculator(self.config)
        return {
            'daily_budget': calc.daily_budget,
            'current_cost': round(calc.get_current_daily_cost(), 6),
            'status': calc.get_budget_status(),
            'action': calc.get_recommended_action()
        }

    def estimate(self, handler):
        runtime_hours = 24
        if 'hours=' in handler.path:
            try:
                runtime_hours = float(handler.path.split('hours=')[-1].split('&')[0])
            except (ValueError, IndexError):
                pass
        runtime_minutes = runtime_hours * 60

        calc = CostCalculator(self.config)
        estimated = calc.estimate_cost(runtime_minutes)

        self._send_json(handler, 200, {
            'estimated_cost': round(estimated, 6),
            'daily_budget': calc.daily_budget,
            'within_budget': estimated <= calc.daily_budget
        })

    def history(self, handler):
        costs = self.db.get_recent_costs(7)
        self._send_json(handler, 200, {'costs': [dict(c) for c in costs]})
