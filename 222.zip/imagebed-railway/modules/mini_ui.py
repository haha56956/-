import json
from modules.base import BaseModule


class MiniUIModule(BaseModule):
    __slots__ = ()

    def handle(self, handler, method, path):
        if path == '/mini' and method == 'GET':
            self.serve_mini(handler)
        elif path == '/mini/upload' and method == 'POST':
            self.quick_upload(handler)
        else:
            handler.send_response(404)
            handler.end_headers()

    def serve_mini(self, handler):
        html = b'''<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Mini ImageBed</title><style>body{font-family:sans-serif;max-width:600px;margin:50px auto;padding:20px}input,button{margin:10px 0;padding:10px;width:100%;box-sizing:border-box}button{background:#007bff;color:#fff;border:none;cursor:pointer}</style></head>
<body><h2>Quick Upload</h2><input type="file" id="file"><button onclick="upload()">Upload</button><div id="result"></div>
<script>async function upload(){const f=document.getElementById('file').files[0];if(!f)return;const fd=new FormData();fd.append('file',f);const r=await fetch('/mini/upload',{method:'POST',body:fd});const d=await r.json();document.getElementById('result').innerHTML=d.url?`<a href="${d.url}">${d.url}</a>`:d.error;}</script>
</body></html>'''

        handler.send_response(200)
        handler.send_header('Content-Type', 'text/html; charset=utf-8')
        handler.send_header('Content-Length', str(len(html)))
        handler.end_headers()
        handler.wfile.write(html)

    def quick_upload(self, handler):
        self._send_error(handler, 401, 'Auth required for mini upload')
