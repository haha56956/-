import os
import sys
import signal
from http.server import HTTPServer, BaseHTTPRequestHandler
from modules.router import Router
from utils.db import Database
from utils.auth import Auth

DB_PATH = os.environ.get('DATABASE_PATH', '/app/data/imagebed.db')
JWT_SECRET = os.environ.get('JWT_SECRET', os.urandom(32).hex())
PORT = int(os.environ.get('PORT', '8080'))


def bootstrap_admin(db, auth):
    username = os.environ.get('ADMIN_USERNAME')
    password = os.environ.get('ADMIN_PASSWORD')
    if not username or not password:
        return
    existing = db.get_user(username)
    if existing is None:
        db.create_user(username, auth.hash_password(password), 'admin')
        print(f'Created admin user "{username}" from environment', flush=True)
    else:
        db.execute('UPDATE users SET password_hash = ?, role = ? WHERE id = ?',
                   (auth.hash_password(password), 'admin', existing['id']))
        print(f'Synced admin user "{username}" from environment', flush=True)


def main():
    dirname = os.path.dirname(DB_PATH)
    if dirname:
        os.makedirs(dirname, exist_ok=True)
    db = Database(DB_PATH)
    auth = Auth(JWT_SECRET)
    bootstrap_admin(db, auth)
    router = Router(db, auth)

    server = HTTPServer(('0.0.0.0', PORT), make_handler(router))
    print(f'Server started on port {PORT}', flush=True)

    def shutdown(signum, frame):
        print('Shutting down...', flush=True)
        server.shutdown()
        db.close()
        sys.exit(0)

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)

    server.serve_forever()


def make_handler(router):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            router.route(self, 'GET')

        def do_POST(self):
            router.route(self, 'POST')

        def do_DELETE(self):
            router.route(self, 'DELETE')

        def do_PUT(self):
            router.route(self, 'PUT')

        def do_PATCH(self):
            self.send_response(405)
            self.end_headers()

        def do_OPTIONS(self):
            self.send_response(200)
            self.send_header('Allow', 'GET, POST, DELETE, PUT')
            self.end_headers()

        def log_message(self, format, *args):
            pass

    return Handler


if __name__ == '__main__':
    main()
