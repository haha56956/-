# ImageBed Railway 部署指南

基于 Railway 免费方案的高性价比 HTML 图床平台，严格控制在每月 $1 用量额度内。

## 目录

- [项目简介](#项目简介)
- [功能特性](#功能特性)
- [成本优化](#成本优化)
- [GitHub 仓库创建](#github-仓库创建)
- [Railway 部署](#railway-部署)
- [环境变量配置](#环境变量配置)
- [使用说明](#使用说明)
- [API 接口文档](#api-接口文档)
- [存储后端配置](#存储后端配置)
- [多服务器互联](#多服务器互联)
- [预算管理](#预算管理)
- [常见问题](#常见问题)

---

## 项目简介

ImageBed Railway 是一款专为 Railway 免费方案设计的图床平台，支持 HTML 和图片托管。采用单进程多模块架构，空闲时仅保留约 30MB 常驻内存，按需唤醒对应模块，任务完成后立即释放资源。

## 功能特性

- 用户注册/登录（JWT 鉴权）
- HTML 和图片上传/下载/预览
- 管理员后台（用户/组管理）
- 用户存储配额和文件数量限制
- 多服务器互联（主从、对等、分发模式）
- 预算预估器（三档自动降级）
- 周统计分析（高频/低峰时段）
- 极简 UI 模式（紧急成本控制）
- Redis/TiDB/S3/Alist/FTP/OSS 六种存储后端
- 速率限制和基础安全防护
- 零外部依赖（纯 Python 标准库）

## 成本优化

| 策略 | 节省效果 |
|------|---------|
| 文件存外部存储 | 避免 Railway 卷存储费用 |
| SQLite 存元数据 | 无需额外数据库服务 |
| `__slots__` 内存优化 | 减少约 40% 内存占用 |
| 速率限制 | 防止恶意请求 |
| 预算熔断器 | 超预算自动关闭非必要模块 |
| 零 pip 依赖 | 冷启动时间最短 |

**目标：每日 $0.03 以内（Railway 免费方案每月 $1 额度内）**

## GitHub 仓库创建

### 步骤 1：创建仓库

1. 访问 https://github.com/new
2. 仓库名称：`imagebed-railway`
3. 可见性：私有（推荐）
4. 不要勾选 "Add a README file"（已有）
5. 点击 "Create repository"

### 步骤 2：推送代码

```bash
cd imagebed-railway
git init
git add .
git commit -m "Initial commit: ImageBed Railway deployment"
git branch -M main
git remote add origin https://github.com/你的用户名/imagebed-railway.git
git push -u origin main
```

## Railway 部署

### 步骤 1：注册 Railway

1. 访问 https://railway.app
2. 使用 GitHub 账号登录（推荐，集成更顺畅）
3. 验证邮箱

### 步骤 2：创建项目

1. 点击 "New Project"
2. 选择 "Deploy from GitHub repo"
3. 授权 Railway 访问 GitHub（如提示）
4. 选择 `imagebed-railway` 仓库
5. Railway 自动检测 Python 项目并部署

### 步骤 3：配置环境变量

在 Railway 项目面板中，进入服务的 "Variables" 标签页，添加以下变量：

**必填变量：**

| 变量名 | 说明 | 生成方式 |
|--------|------|---------|
| `JWT_SECRET` | JWT 签名密钥 | `openssl rand -hex 32` |
| `ADMIN_USERNAME` | 初始管理员账号（首次启动自动创建） | 自定义 |
| `ADMIN_PASSWORD` | 初始管理员密码（每次启动会同步为管理员密码） | 自定义 |
| `STORAGE_TYPE` | 存储后端类型 | `redis` / `tidb` / `s3` / `alist` / `ftp` / `oss` / `none` |
| `DAILY_BUDGET` | 每日预算上限（美元） | `0.03` |

> **后台可配置：** 除管理员账号、管理员密码和 `JWT_SECRET` 外，其余环境变量（存储后端、预算、容量、限流、站点设置等）均可在管理后台 **Settings** 标签页在线修改并即时生效，无需重启。数据库中已保存的值优先于环境变量。管理员密码可在后台 **Security** 标签页修改。

**存储后端专属变量：**

**Redis：**

| 变量名 | 说明 |
|--------|------|
| `REDIS_URL` | Redis 连接地址，如 `redis://default:密码@主机:6379/0` |

**TiDB：**

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `TIDB_HOST` | TiDB 服务器地址 | - |
| `TIDB_PORT` | TiDB 端口 | `4000` |
| `TIDB_USER` | 数据库用户名 | - |
| `TIDB_PASSWORD` | 数据库密码 | - |
| `TIDB_DATABASE` | 数据库名 | `imagebed` |

**S3（AWS、MinIO、Cloudflare R2 等）：**

| 变量名 | 说明 |
|--------|------|
| `STORAGE_BUCKET` | S3 存储桶名称 |
| `STORAGE_ENDPOINT` | S3 端点 URL（MinIO 等兼容服务需要） |
| `STORAGE_ACCESS_KEY` | Access Key |
| `STORAGE_SECRET_KEY` | Secret Key |

**Alist：**

| 变量名 | 说明 |
|--------|------|
| `ALIST_URL` | Alist 服务器地址 |
| `ALIST_TOKEN` | Alist 认证 Token |

**FTP：**

| 变量名 | 说明 |
|--------|------|
| `FTP_HOST` | FTP 服务器地址 |
| `FTP_USER` | FTP 用户名 |
| `FTP_PASS` | FTP 密码 |

**OSS（阿里云）：**

| 变量名 | 说明 |
|--------|------|
| `OSS_ENDPOINT` | OSS 端点 |
| `OSS_BUCKET` | OSS 存储桶名称 |
| `OSS_ACCESS_KEY` | Access Key |
| `OSS_SECRET_KEY` | Secret Key |

### 步骤 4：部署

Railway 自动完成：
1. 检测 Python 项目
2. 使用 Nixpacks 构建
3. 部署到免费实例
4. 分配公网 URL（如 `https://imagebed-railway.up.railway.app`）

### 步骤 5：验证部署

```bash
curl https://你的应用地址/health
# 应返回: {"status":"ok"}
```

## 使用说明

### Web 界面

1. 访问 Railway 分配的应用 URL
2. 注册新账户
3. 上传 HTML 或图片文件
4. 通过 `/f/:token` 链接访问文件

### 管理员后台

1. 访问 `/admin` 进入管理面板
2. 管理用户、组、服务器和系统配置

### 创建首个管理员

```bash
# 注册用户后，在 Railway Shell 中执行：
sqlite3 /app/data/imagebed.db "UPDATE users SET role='admin' WHERE username='你的用户名';"
```

## API 接口文档

### 用户认证

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/user/register` | POST | 注册新用户 |
| `/api/user/login` | POST | 登录获取 JWT Token |
| `/api/user/profile` | GET | 获取用户信息 |

### 文件管理

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/upload` | POST | 上传文件（multipart/form-data） |
| `/api/files` | GET | 获取文件列表 |
| `/api/files/:id` | DELETE | 删除文件 |
| `/f/:token` | GET | 访问文件（公开） |

### 管理接口

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/admin/users` | GET | 用户列表 |
| `/api/admin/users` | POST | 创建用户 |
| `/api/admin/users/:id` | PUT | 修改用户配额 |
| `/api/admin/users/:id` | DELETE | 删除用户 |
| `/api/admin/groups` | GET | 用户组列表 |
| `/api/admin/groups` | POST | 创建用户组 |
| `/api/admin/groups/:id` | PUT | 修改用户组 |
| `/api/admin/groups/:id` | DELETE | 删除用户组 |
| `/api/admin/config` | GET | 获取系统配置 |
| `/api/admin/config` | PUT | 修改系统配置 |
| `/api/admin/stats` | GET | 系统统计 |

### 预算管理

| 接口 | 方法 | 说明 |
|------|------|------|
| `/budget/status` | GET | 当前预算状态 |
| `/api/budget/estimate` | GET | 预估成本（参数: hours=24） |
| `/api/budget/history` | GET | 历史成本记录 |

### 调度分析

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/scheduler/analyze` | POST | 分析流量模式 |
| `/api/scheduler/report` | GET | 获取流量报告 |

### 服务器管理

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/servers` | GET | 服务器列表 |
| `/api/servers` | POST | 添加服务器 |
| `/api/servers/:id` | DELETE | 移除服务器 |

## 存储后端配置

### Redis（推荐小文件）

```bash
# 需要: pip install redis
# 环境变量: REDIS_URL=redis://default:密码@主机:6379/0
```

### TiDB（推荐大规模）

```bash
# 需要: pip install pymysql
# 环境变量: TIDB_HOST, TIDB_PORT, TIDB_USER, TIDB_PASSWORD, TIDB_DATABASE
```

### S3（AWS、MinIO、Cloudflare R2 等）

```bash
# 需要: pip install boto3
# 环境变量: STORAGE_BUCKET, STORAGE_ENDPOINT, STORAGE_ACCESS_KEY, STORAGE_SECRET_KEY
```

### Alist

```bash
# 无需额外依赖
# 环境变量: ALIST_URL, ALIST_TOKEN
```

### FTP

```bash
# 无需额外依赖
# 环境变量: FTP_HOST, FTP_USER, FTP_PASS
```

### OSS（阿里云）

```bash
# 需要: pip install oss2
# 环境变量: OSS_ENDPOINT, OSS_BUCKET, OSS_ACCESS_KEY, OSS_SECRET_KEY
```

## 多服务器互联

### 主从关系

1. 在主服务器后台「服务器」标签页
2. 添加从服务器 URL 和授权 Token
3. 角色设为「Slave（从）」

### 对等关系（资源互借）

1. 在两台服务器上互相添加对方为对等节点
2. 一台服务器资源不足时自动借用另一台资源

### 分发模式

1. 设置一台主服务器
2. 添加所有其他服务器为从节点
3. 主服务器自动将请求分发到从节点

## 预算管理

### 预算状态级别

| 状态 | 阈值 | 动作 |
|------|------|------|
| 正常 | < 70% | 全部功能开放 |
| 警告 | 70-90% | 关闭调度分析、服务器互联 |
| 紧急 | > 90% | 极简 UI，仅保留上传/下载 |

### 查看预算状态

```bash
curl https://你的应用地址/budget/status
```

返回示例：
```json
{
  "daily_budget": 0.03,
  "current_cost": 0.015,
  "status": "normal",
  "action": "all_features"
}
```

## 常见问题

### 服务无法启动

1. 查看 Railway 面板日志
2. 确认所有必填环境变量已设置
3. 检查 `JWT_SECRET` 是否已配置

### 上传失败

1. 检查存储后端配置是否正确
2. 验证存储服务凭据
3. 确认存储桶/数据库已创建

### 预算超标

1. 访问 `/budget/status` 查看状态
2. 在管理员后台降低每日预算
3. 等待自动降级到极简模式

### 数据库锁定

1. SQLite WAL 模式默认启用
2. 如问题持续，重启服务即可

## 许可证

MIT
